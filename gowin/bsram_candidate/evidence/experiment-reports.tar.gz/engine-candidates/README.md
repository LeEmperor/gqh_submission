# Scalar BSRAM engine experiment handoff

The preserved parent is H2/H4 competition RTL SHA-256
`cbd88a4e72e8476fa7e22acd464c6e3e596d8c81a89ca3a5d5c4192a10ebe818`.
Only the isolated `engine-workspace` and this evidence directory were edited.
No production files, Git index, refs, Windows tool settings, or board state were
changed by this agent.

## Implementation

`api-and-dual-verification-normal/src/engine/update.ml` and `.mli` contain the
final normal option implementation. `records_in_bram` defaults false, preserving
the original scalar register implementation. When enabled, `engine_records` is
a synchronous uninitialized 2×24 array: sum bits 19:0, previous-below bit 20,
previous-above bit 21, held-action bits 23:22. Two resettable validity bits mask
unwritten/stale records to zero. Reset and idle session clear invalidate both
records, clear output/control, and never reset either memory. Both memories
commit exactly once on E2, with no writes during result stalls. Warm-up commits
the comparison flags, including index 15, for the first scored index 16.

Engine publication remains E0+2; earliest result transfer E0+3; earliest next
acceptance E0+4. Controller response transfer remains 11 clocks for session
start and 9 for warm-up/steady commands. Direct 27 MHz, divisor 234, complete
UART stop bits, real heartbeat, full 16-bit prices and exact 20-bit sums are
preserved. The arithmetic agent's opt-in `borrow_command`, `delta_arithmetic`,
and `difference_relation` options work with either record storage mode.

The pinned Yosys 0.69+187 maps history to SPX9 BIT_WIDTH=18 and records to SPX9
BIT_WIDTH=36, both synchronous bypass/no-change with RAM reset inactive. The
source read and write enables never overlap. Record storage costs a second
BSRAM and removes 46 fabric registers before command borrowing. The baseline
engine has 74 fabric registers, normal record BSRAM has 28, and borrowed record
BSRAM has 6, before whole-design composition/packing changes.

Authoritative memory documentation and the architectural checks are recorded
in `i1-records-parallel/research.md`. A shared 64×24 single-port array was
considered architecturally: the history and record reads would require a
16-bit oldest-value latch, and the two different-address writes would require
additional phases/address/data muxes. This was not implemented or measured;
it is not counted as a rejected measured candidate. A 24-bit true dual-port
record does not fit the single-block 18-bit maximum true-dual-port mode.

## Verification

Every seven retained candidate engine passes the independent direct-window
oracle, 104,927 Cyclesim edges, 104,927 emitted-RTL Icarus edges, deterministic
emission, and Yosys structural checks. Tests poison all history cells and both
scalar records, check every physical memory cell at every edge, compare scalar
records to direct windows, test all price/average relation transitions, warm-up
index 15/16, full-range extremes, swaps, wraps, stalls, exact-once commits,
session clear and reset at every processing/result phase.

Borrowed-input tests hold producer fields only from acceptance through E2;
they change every field during result stalls and still require stable output.
Captured-input tests continue changing every field while the command is busy.
The dual-mode focused files in `api-and-dual-verification-normal/test/engine/`
select RAM with `HOPT_RECORDS_IN_BRAM=1`; the default retains the original FF
checks. Both default FF and RAM+all-three-options pass; their logs are retained
alongside the files. The normal bundle has no inverted-address API dependency.

`i1-records-parallel/integration.log` passes the full protocol replay (4,669
packets/9,338 commands), all ten serial Cyclesim control variants, all 1,394
production-divisor emitted-RTL UART packets, startup/full-stop/fault/busy checks,
RX/engine/TX reset recovery, and unchanged heartbeat. `i4-records-borrow-relation`
also completes all 1,394 production-divisor packets and recovery checks, with
matching RTL, coverage and raw latency samples under `serial-evidence/`.

The other normal engine combinations pass 1,394 serial Cyclesim packets and
deterministic matching competition RTL. Their unselected production-divisor
Icarus jobs were cancelled at the parent's request to prioritize the selected
composed finalists. These jobs are explicitly **not full-UART qualified**.
The root agent owns the exact selected 2/3-BSRAM full UART runs and board/vendor
qualification.

`i1-records-parallel/vendor-mapped-engine/` passes all 104,927 public engine
trace edges with the installed Gowin functional SPX9 model, pinned Yosys logic
models, and poisoned physical RAM. The inverted all-three-options experiment
also passes the same public mapped check with its held-producer trace. These
are mapped functional checks, not Gowin synthesis, postroute timing, or board
acceptance.

## Open-source screens and preserved rejects

All seven standalone storage-combination P&R runs fail four nextpnr hold checks
at the width-36 record read-address port (−0.12 ns). Their setup constraints
pass at 27 MHz. Every runner manifest correctly remains `invalid`, with no
accepted resource result or bitstream. `engine-screen-ledger.json` retains
the following **diagnostic counters only**; they must not be ranked as valid
timing-passing screens or labelled Gowin Logic/register measurements.

| Experiment | Diagnostic LUT4+ALU | Diagnostic DFF | BSRAM | Whole UART |
| --- | ---: | ---: | ---: | --- |
| i1 records | 578 | 201 | 2 | PASS |
| i2 records + borrow | 600 | 179 | 2 | Cancelled |
| i3 records + relation | 533 | 201 | 2 | Cancelled |
| i4 records + borrow + relation | 567 | 179 | 2 | PASS |
| i5 records + all three arithmetic/retention options | 506 | 179 | 2 | Cancelled |
| i6 records + delta + relation, captured command | 513 | 201 | 2 | Cancelled |
| i7 inverted record banks + all three options | 508 | 179 | 2 | Not started |

The sole inverted bank-address experiment adds an optional physical permutation
without changing logical item routing. Focused and mapped poison tests pass,
but hold still fails and diagnostic logic rises. It is preserved as an
experimental reject in `i7-records-all3-inverted`; its API and tests are not
required by the final normal implementation bundle.

The root subsequently reports the exact composed normal 3-BSRAM candidate was
measured by the user in Gowin at **302 Logic / 109 registers / 3 BSRAM**, with
zero setup/hold violations, versus identified baseline 363 / 235 / 1. The root
owns those raw vendor reports, exact composed RTL identity, final promotion,
and board acceptance; these standalone invalid nextpnr screens do not replace
that vendor evidence.

Each candidate retains source, generated standalone/full competition RTL,
parent/input hashes, focused evidence, source review patch, pinned-tool commands,
complete failed P&R logs/netlists/reports, and explicit verification scope.
Cancelled jobs and the initial i6 missing-tool failure remain preserved.
