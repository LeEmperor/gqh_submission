The three candidates independently parent the selected H2/H4 competition RTL
cbd88a4e72e8476fa7e22acd464c6e3e596d8c81a89ca3a5d5c4192a10ebe818.
They retain baseline engine command capture. No whole-design savings are inferred
from source widths; root performs serialized whole-design routing measurements.

Packet RAM owns all eight bytes from an enabled valid byte write through final TX
frame drain. Every new packet writes all addresses 0..7 before any engine dispatch
or echo read. Framing errors cannot produce acceptance; busy faults inhibit future
reception but preserve the accepted packet. Reset clears position, FSM and flags,
aborts dispatch/TX, and requires eight fresh byte writes before any RAM read.
Thus previous contents and a previously latched RAM Q are invalid after reset.

| Field | Source | Last consumption | Stability |
| --- | --- | --- | --- |
| index, IDs | 8x8 packet RAM | echo index/IDs during eight-byte response | no writes outside Idle reception |
| session, warmup | two flags derived from first two bytes | clear and both engine updates | no writes after second received byte |
| engine item | one flag from ID read | result transfer | next ID read occurs after result transfer |
| engine price high | eight-bit register from high-byte read | result transfer | next high read occurs after result transfer |
| engine price low | synchronous RAM output from low-byte read | result transfer | read disabled during Dispatch/Result |
| engine window position | four-bit circular pointer | command commit | second Result increments after commit |
| slot actions | two two-bit registers | response action bytes | unchanged through final drain |
| response position | shared receive/echo three-bit position | final drain | framing fault resets it only in Idle |

Packet RAM trades the original 64 payload FFs and separate protocol data muxes
for another physical BSRAM, RAM reads, an eight-bit high-price register and narrow
flags. It schedules ID/high/low reads across three cycles per slot. Send adds a
synchronous read bubble between response bytes; UART still completes all start,
data and stop durations. This extra RAM is intentionally separate from engine
history; combining the memories is a later independent architecture change.

The timer candidates factor reload, decrement and enable controls. They may
allow an inactive timer to underflow at a terminal Stop/Gap or false-start edge;
that value is ignored in Idle and overwritten at next acceptance/start. Exact
external durations, independent RX/TX timers, divisor 234 and heartbeat remain.
Both standalone UART options default false; packet RAM also defaults false.

Primary architecture reference: Gowin B-SRAM User Guide UG285-1.09E,
https://www.gowinsemi.com/upload/database_doc/6/document/5b5852bfdb1b1.pdf
Sections 2.1, 3.2 and 3.3 document 18 Kbit blocks, supported widths, synchronous
read/write clocks, and read-before-write mode. The experiment uses an inferred
unreset 8-bit synchronous RAM with syn_ramstyle="block_ram". Mapping and address
bits must be audited from the resulting netlist, as with the existing engine RAM.

Verification logs are local: packet-ram-focused.log, packet-ram-cyclesim.log,
packet-ram-integration.log; uart-transport.log, uart-tx-boundary.log;
rx-timer-cyclesim.log, tx-timer-cyclesim.log and their Icarus logs.
Production Icarus tests retain all 1,394 oracle rows, true startup, arbitrary
legal byte pauses, complete stops, busy/framing lockout, populated-history reset
during all request bytes, both slots' engine phases, all response bytes, and real
13.5M-cycle heartbeat. packet_ram_tb.v adapts only acceptance/receive monitoring
and adds RAM latency measurement. Legacy latency is response-offer timing;
packet RAM latency is final-byte acceptance to first TX acceptance, kept separate.

Completed open-source screens (not official Gowin measurements):

| Independent candidate | LUT4 utilization | ALU | Proxy | DFF | BSRAM | Fmax estimate MHz |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| H2/H4 selected parent | 441 | 144 | 585 | 247 | 1 | 150.85 |
| Packet RAM | 350 | 132 | 482 | 190 | 2 | 140.53 |
| RX factored timer | 437 | 144 | 581 | 247 | 1 | 143.78 |
| TX factored timer | 455 | 144 | 599 | 247 | 1 | 146.61 |

All screens meet the unchanged 27MHz timing constraint. Full manifests and
matching bitstreams live in builds/<candidate>. The packet is a DPX9B mapped
to 9-bit read/write ports with all three live address bits (ADA/ADB[5:3]) and
eight live data bits. The engine remains SPX9 with five live address bits.
READ_MODE0/1=0; WRITE_MODE0/1=1; the read port never writes and write/read phases
are exclusive. packet-ram-primitive-audit.json preserves exact parameters and
connections. Source whitespace polishing reproduces identical RTL hashes.

Packet RAM first-TX latency samples are session18/non-session16 clocks,
measured from final-byte acceptance and separate from controller response-offer
latency. UART input/output wire timing and entire stop bits are tested at the
unchanged production divisor.

Rejected RX output borrowing hypothesis: baseline RX already exports the single
eight-bit receive shift register directly as byte_data; there is no additional
eight-bit output capture register to remove. The 24-register vendor RX profile
accounts for previous1 + timer8 + bit index3 + data8 + valid1 + error1 + FSM2.
No unchanged RXborrow candidate was created or counted as a measurement. The
RX interface now precisely documents byte_data stability during byte_valid and
its permitted shifting in a subsequent frame, with no hardware change.
